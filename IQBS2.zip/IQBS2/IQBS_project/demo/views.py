from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse

# Create your views here.
'''def data(request):
      
      #return JsonResponse({'message':'this is IQBS'})
      return render(request, 'index.html')'''
def login(request):
      return render(request, 'login.html')

def home(request):
      return render(request, 'home.html')
def create(request):
      return render(request, 'createQuestion.html')

def view(request):
      return render(request, 'View_question.html')
def analyze(request):
      return render(request, 'analyzeReport.html')