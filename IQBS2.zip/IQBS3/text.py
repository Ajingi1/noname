'''# Bloom's Taxonomy Keywords and Levels
bloom_keywords = {
    "C1": ["define", "list", "recall", "identify", "describe", "recognize", "retrieve", "name", "state"],
    "C2": ["explain", "summarize", "paraphrase", "classify", "interpret", "compare", "discuss", "restate"],
    "C3": ["solve", "use", "implement", "demonstrate", "perform", "apply", "execute", "modify",],
    "C4": ["analyze", "differentiate", "organize", "attribute", "structure", "compare", "test", "examine","calculate"],
    "C5": ["assess", "critique", "evaluate", "judge", "recommend", "justify", "argue", "defend", "decide"],
    "C6": ["design", "construct", "develop", "build", "create", "generate", "compose", "plan", "propose"]
}

def find_bloom_level(user_input):
    # Normalize input by converting to lowercase and splitting into words
    words = user_input.lower().split()
    matched_keywords = {}


    # Compare each word with Bloom keywords
    for word in words:
        for level, keywords in bloom_keywords.items():
            if word in keywords:
                if level not in matched_keywords:
                    matched_keywords[level] = []
                matched_keywords[level].append(word)

    return matched_keywords

# Take user input
user_input = input("Enter a string: ")

# Find Bloom levels
results = find_bloom_level(user_input)

# Display results
if results:
    print("Matching Bloom Levels:")
    for level, keywords in results.items():
        print(f"{level}: {', '.join(keywords)}")
else:
    print("No matching Bloom keywords found.")
'''



# Load the SpaCy English model for NLP
nlp = spacy.load("en_core_web_sm")

# Bloom Taxonomy keywords grouped by levels
bloom_taxonomy = {
    "C1": ["define", "list", "recall", "identify", "describe", "recognize", "retrieve", "name", "state"],
    "C2": ["explain", "summarize", "paraphrase", "classify", "interpret", "compare", "discuss", "restate"],
    "C3": ["solve", "use", "implement", "demonstrate", "perform", "apply", "execute", "modify"],
    "C4": ["analyze", "differentiate", "organize", "attribute", "structure", "compare", "test", "examine"],
    "C5": ["assess", "critique", "evaluate", "judge", "recommend", "justify", "argue", "defend", "decide"],
    "C6": ["design", "construct", "develop", "build", "create", "generate", "compose", "plan", "propose"],
}

# Function to process the input and classify words based on Bloom levels
def classify_bloom_level(user_input):
    # Tokenize and normalize input using spaCy
    doc = nlp(user_input.lower())

    # Result dictionary to store matched keywords and their levels
    results = {level: [] for level in bloom_taxonomy.keys()}

    # Compare each token with Bloom's keywords
    for token in doc:
        if not token.is_alpha:  # Skip non-alphabetic tokens
            continue
        for level, keywords in bloom_taxonomy.items():
            if token.text in keywords:
                results[level].append(token.text)

    # Remove duplicates and format the output
    for level in results:
        results[level] = list(set(results[level]))

    return results

# Main function to take user input and provide classification
if __name__ == "__main__":
    user_input = input("Enter a sentence: ")
    bloom_results = classify_bloom_level(user_input)

    # Display the output
    print("\nBloom Level Classification:")
    for level, words in bloom_results.items():
        if words:
            print(f"{level}: {', '.join(words)}")
        else:
            print(f"{level}: No matches")
