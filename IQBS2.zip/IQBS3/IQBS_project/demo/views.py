from django.shortcuts import render, redirect
from django.http import JsonResponse
from .models import Question  # Import the Question model

# Bloom Taxonomy keywords grouped by levels
bloom_taxonomy = {
    "C1": ["define", "list", "recall", "identify", "describe", "recognize", "retrieve", "name", "state"],
    "C2": ["explain", "summarize", "paraphrase", "classify", "interpret", "compare", "discuss", "restate"],
    "C3": ["solve", "use", "implement", "demonstrate", "perform", "apply", "execute", "modify"],
    "C4": ["analyze", "differentiate", "organize", "attribute", "structure", "compare", "test", "examine"],
    "C5": ["assess", "critique", "evaluate", "judge", "recommend", "justify", "argue", "defend", "decide"],
    "C6": ["design", "construct", "develop", "build", "create", "generate", "compose", "plan", "propose"],
}

def classify_bloom_level(user_input):
    """Classify the question based on Bloom's taxonomy."""
    words = user_input.lower().split()  # Tokenize the input text into words
    for level, keywords in bloom_taxonomy.items():
        for word in words:
            if word in keywords:
                return level, word  # Return the first match
    return None, None  # If no match is found

def create(request):
    if request.method == 'POST':
        question_id = request.POST.get('serial-number')
        subject_code = request.POST.get('subject-code')
        question_text = request.POST.get('question')

        # Classify the Bloom level and keyword
        bloom_level, bloom_keyword = classify_bloom_level(question_text)

        # Save the question in the database
        question = Question(
            id=question_id,
            subject_code=subject_code,
            question_text=question_text,
            bloom_level=bloom_level if bloom_level else "Unclassified",
            bloom_keyword=bloom_keyword if bloom_keyword else "None"
        )
        question.save()

        return redirect('home')  # Redirect to the home page after submission

    return render(request, 'createQuestion.html')

'''def data(request):
      
      #return JsonResponse({'message':'this is IQBS'})
      return render(request, 'index.html')'''
def login(request):
      return render(request, 'login.html')

def home(request):
      return render(request, 'home.html')


def view(request):
    # Retrieve all questions from the database
    questions = Question.objects.all()
    
    # Pass the questions to the template
    return render(request, 'View_question.html', {'questions': questions})
def analyze(request):
    # Retrieve all questions from the database
    questions = Question.objects.all()

    # Classify questions into difficulty levels
    difficulty_levels = {
        "easy": [],
        "medium": [],
        "hard": []
    }

    for question in questions:
        bloom_level = question.bloom_level
        if bloom_level in ["C1", "C2"]:
            difficulty_levels["easy"].append(question)
        elif bloom_level in ["C3", "C4"]:
            difficulty_levels["medium"].append(question)
        elif bloom_level in ["C5", "C6"]:
            difficulty_levels["hard"].append(question)

    # Pass the classified questions to the template
    return render(request, 'analyzeReport.html', {"difficulty_levels": difficulty_levels})